const STATE = {
  config: {
    platformPatterns: [
      { name: "Safka", url_pattern: "safka-eg.com", is_active: true },
      { name: "Taager", url_pattern: "taager.com", is_active: true },
      { name: "Vendor EG", url_pattern: "vendor-eg.com", is_active: true }
    ],
    userId: "demo-user"
  },
  queue: [],
  flushTimer: null
};

chrome.runtime.sendMessage({ type: "STOCKPULSE_GET_CONFIG" }, (config) => {
  STATE.config = config || STATE.config;
});

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "STOCKPULSE_PAGE") return;

  const platform = detectPlatform(event.data.url, STATE.config.platformPatterns);
  if (!platform) return;

  const products = extractProducts(event.data.body, platform.name);
  if (products.length === 0) return;

  STATE.queue.push(...products);
  scheduleFlush(platform.name);
});

function detectPlatform(url, patterns) {
  const haystack = `${location.href} ${url || ""}`.toLowerCase();
  return (patterns || []).find((platform) => {
    if (platform.is_active === false) return false;
    return haystack.includes(String(platform.url_pattern || "").toLowerCase());
  });
}

function scheduleFlush(platform) {
  clearTimeout(STATE.flushTimer);
  STATE.flushTimer = setTimeout(() => {
    const products = [...STATE.queue];
    STATE.queue = [];
    chrome.runtime.sendMessage({
      type: "STOCKPULSE_INGEST",
      payload: { products, platform }
    });
  }, 900);
}

function extractProducts(body, platformName) {
  const objects = [];
  walkJson(body, (value) => {
    if (isProductLike(value)) {
      const normalized = normalizeProduct(value, platformName);
      if (normalized) objects.push(normalized);
    }
  });
  return objects;
}

function walkJson(value, visitor, seen = new WeakSet()) {
  if (!value || typeof value !== "object") return;
  if (seen.has(value)) return;
  seen.add(value);

  if (Array.isArray(value)) {
    value.forEach((item) => walkJson(item, visitor, seen));
    return;
  }

  visitor(value);
  Object.values(value).forEach((item) => walkJson(item, visitor, seen));
}

function isProductLike(value) {
  const keys = Object.keys(value).map((key) => key.toLowerCase());
  const hasName = keys.some((key) => ["name", "title", "product_name", "productname", "اسم", "name_ar"].includes(key));
  const hasQuantity = keys.some((key) =>
    ["quantity", "qty", "stock", "available_quantity", "current_quantity", "inventory", "available", "الكمية"].includes(key)
  );
  return hasName && hasQuantity;
}

function normalizeProduct(value, platformName) {
  const productId = pick(value, ["product_id", "productId", "id", "sku", "code"]);
  const productName = pick(value, ["product_name", "productName", "name", "title", "name_ar", "اسم"]);
  const currentQuantity = Number(pick(value, ["current_quantity", "quantity", "qty", "stock", "available_quantity", "inventory", "available", "الكمية"]));

  if (!productId || !productName || Number.isNaN(currentQuantity)) return null;

  return {
    product_id: String(productId),
    product_name: String(productName),
    current_quantity: Math.max(0, Math.trunc(currentQuantity)),
    price: Number(pick(value, ["price", "sale_price", "final_price", "cost", "السعر"]) || 0),
    image_url: pick(value, ["image_url", "image", "thumbnail", "main_image", "صورة"]) || null,
    platform_name: platformName,
    timestamp: new Date().toISOString()
  };
}

function pick(object, keys) {
  for (const key of keys) {
    if (object[key] !== undefined && object[key] !== null && object[key] !== "") return object[key];
  }

  const lowerMap = Object.fromEntries(Object.keys(object).map((key) => [key.toLowerCase(), key]));
  for (const key of keys) {
    const found = lowerMap[key.toLowerCase()];
    if (found && object[found] !== undefined && object[found] !== null && object[found] !== "") return object[found];
  }

  return null;
}
