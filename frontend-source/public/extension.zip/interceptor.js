(function stockPulseInterceptor() {
  const postJson = (url, body) => {
    if (!body || typeof body !== "object") return;
    window.postMessage({ source: "STOCKPULSE_PAGE", url, body }, "*");
  };

  const originalFetch = window.fetch;
  window.fetch = async function stockPulseFetch(input, init) {
    const response = await originalFetch.apply(this, arguments);
    try {
      const clone = response.clone();
      const contentType = clone.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        clone.json().then((body) => postJson(typeof input === "string" ? input : input.url, body)).catch(() => {});
      }
    } catch (error) {
      // Keep page behavior untouched if parsing fails.
    }
    return response;
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function stockPulseOpen(method, url) {
    this.__stockPulseUrl = url;
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function stockPulseSend() {
    this.addEventListener("load", function () {
      try {
        const contentType = this.getResponseHeader("content-type") || "";
        if (contentType.includes("application/json") && typeof this.responseText === "string") {
          postJson(this.__stockPulseUrl, JSON.parse(this.responseText));
        }
      } catch (error) {
        // Keep page behavior untouched if parsing fails.
      }
    });
    return originalSend.apply(this, arguments);
  };
})();
