const nf = new Intl.NumberFormat("ar-EG");

document.addEventListener("DOMContentLoaded", async () => {
  await renderStatus();
  document.getElementById("save").addEventListener("click", saveConfig);
});

async function renderStatus() {
  chrome.runtime.sendMessage({ type: "STOCKPULSE_GET_STATUS" }, (status) => {
    const connected = Boolean(status?.connected);
    document.getElementById("statusDot").classList.toggle("ok", connected);
    document.getElementById("statusText").textContent = connected ? "متصل" : "غير متصل";
    document.getElementById("lastSync").textContent = status?.lastSyncAt ? formatDate(status.lastSyncAt) : "لا يوجد";
    document.getElementById("activePlatforms").textContent = nf.format(status?.activePlatforms || 0);
    document.getElementById("productCount").textContent = `${nf.format(status?.syncedProducts || 0)} منتجات`;
    document.getElementById("apiUrl").value = status?.apiUrl || "http://localhost:3000/api";
    document.getElementById("userId").value = status?.userId || "demo-user";
    document.getElementById("error").textContent = status?.error || "";
  });
}

function saveConfig() {
  const apiUrl = document.getElementById("apiUrl").value.trim();
  const userId = document.getElementById("userId").value.trim();
  chrome.runtime.sendMessage({ type: "STOCKPULSE_SAVE_CONFIG", payload: { apiUrl, userId } }, async () => {
    document.getElementById("error").textContent = "تم الحفظ";
    await renderStatus();
  });
}

function formatDate(value) {
  return new Intl.DateTimeFormat("ar-EG", {
    hour: "2-digit",
    minute: "2-digit",
    day: "numeric",
    month: "short"
  }).format(new Date(value));
}
