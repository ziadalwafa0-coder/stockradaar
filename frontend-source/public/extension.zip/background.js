const DEFAULT_API_URL = "http://localhost:3000/api";
const DEFAULT_USER_ID = "demo-user";
const DEFAULT_PATTERNS = [
  { name: "Safka", url_pattern: "safka-eg.com", is_active: true },
  { name: "Taager", url_pattern: "taager.com", is_active: true },
  { name: "Vendor EG", url_pattern: "vendor-eg.com", is_active: true }
];

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(["apiUrl", "userId", "platformPatterns"]);
  await chrome.storage.local.set({
    apiUrl: current.apiUrl || DEFAULT_API_URL,
    userId: current.userId || DEFAULT_USER_ID,
    platformPatterns: current.platformPatterns || DEFAULT_PATTERNS,
    status: {
      connected: false,
      lastSyncAt: null,
      activePlatforms: DEFAULT_PATTERNS.length,
      syncedProducts: 0,
      error: ""
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "STOCKPULSE_GET_CONFIG") {
    getConfig().then(sendResponse);
    return true;
  }

  if (message.type === "STOCKPULSE_INGEST") {
    ingestProducts(message.payload)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "STOCKPULSE_GET_STATUS") {
    getStatus().then(sendResponse);
    return true;
  }

  if (message.type === "STOCKPULSE_SAVE_CONFIG") {
    saveConfig(message.payload).then(sendResponse);
    return true;
  }

  return false;
});

async function getConfig() {
  const store = await chrome.storage.local.get(["apiUrl", "userId", "platformPatterns"]);
  return {
    apiUrl: store.apiUrl || DEFAULT_API_URL,
    userId: store.userId || DEFAULT_USER_ID,
    platformPatterns: store.platformPatterns || DEFAULT_PATTERNS
  };
}

async function saveConfig(payload) {
  const next = {
    apiUrl: payload.apiUrl || DEFAULT_API_URL,
    userId: payload.userId || DEFAULT_USER_ID
  };

  if (Array.isArray(payload.platformPatterns)) {
    next.platformPatterns = payload.platformPatterns;
  }

  await chrome.storage.local.set(next);
  await refreshPlatforms();
  return { ok: true };
}

async function getStatus() {
  const store = await chrome.storage.local.get(["status", "platformPatterns", "apiUrl", "userId"]);
  return {
    ...(store.status || {}),
    activePlatforms: (store.platformPatterns || DEFAULT_PATTERNS).filter((platform) => platform.is_active !== false).length,
    apiUrl: store.apiUrl || DEFAULT_API_URL,
    userId: store.userId || DEFAULT_USER_ID
  };
}

async function ingestProducts(payload) {
  const config = await getConfig();
  const products = dedupeProducts(payload.products || []);
  if (products.length === 0) return { received: 0 };

  const response = await fetch(`${config.apiUrl}/scrape/ingest`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      products,
      platform: payload.platform,
      user_id: config.userId
    })
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(body.error || "تعذر إرسال بيانات المخزون");
  }

  await chrome.storage.local.set({
    status: {
      connected: true,
      lastSyncAt: new Date().toISOString(),
      activePlatforms: config.platformPatterns.filter((platform) => platform.is_active !== false).length,
      syncedProducts: products.length,
      error: ""
    }
  });

  return body;
}

async function refreshPlatforms() {
  const config = await getConfig();
  try {
    const response = await fetch(`${config.apiUrl}/platforms`);
    const body = await response.json();
    if (Array.isArray(body.data)) {
      await chrome.storage.local.set({ platformPatterns: mergePatterns(DEFAULT_PATTERNS, body.data) });
    }
  } catch (error) {
    await chrome.storage.local.set({
      status: {
        connected: false,
        lastSyncAt: null,
        activePlatforms: DEFAULT_PATTERNS.length,
        syncedProducts: 0,
        error: error.message
      }
    });
  }
}

function dedupeProducts(products) {
  const map = new Map();
  for (const product of products) {
    if (!product.product_id || !product.product_name) continue;
    map.set(String(product.product_id), product);
  }
  return [...map.values()];
}

function mergePatterns(base, extra) {
  const map = new Map();
  for (const item of [...base, ...extra]) {
    map.set(item.url_pattern, {
      name: item.name,
      url_pattern: item.url_pattern,
      is_active: item.is_active !== false
    });
  }
  return [...map.values()];
}
